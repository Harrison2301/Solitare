package controller;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import beans.IBoard;
import constants.Names;
import view.PileView;

public class PileController implements MouseListener {

	private IBoard board;
	private ObservableCard observer;
	
	public PileController(IBoard board) {
		this.board = board;
	}
	
	public void attachObserver(ObservableCard observer) {
		this.observer = observer;
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		
		PileView pileView = (PileView) e.getComponent();
		
		if (Names.STK_NAME.contentEquals(pileView.getName())) {
			board.refreshTalon();
			if (observer.getCardInMotion() != null) {
				observer.reset();
			}
		}
		
//		if (observer.getCardInMotion() != null) {
//			String from = ((PileView) observer.getCardInMotion().getParent()).getName();
//			try {
//				board.stack(pileView.getName(), from , observer.getCardInMotion().getIndex());
//			} catch (Exception ignored) {}
//			observer.reset();
//		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
