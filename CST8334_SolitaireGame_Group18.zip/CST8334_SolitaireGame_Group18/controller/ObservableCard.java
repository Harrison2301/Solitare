package controller;

import view.CardView;

public interface ObservableCard {
	void update();
	void reset();
	CardView getCardInMotion();
}
