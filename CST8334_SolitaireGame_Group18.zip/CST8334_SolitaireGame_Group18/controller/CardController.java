package controller;

import java.awt.Component;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.JLayeredPane;
import javax.swing.SwingUtilities;
import beans.IBoard;
import view.BoardView;
import view.CardView;
import view.FoundationView;
import view.PileView;
import view.TableauView;

public class CardController implements MouseListener, MouseMotionListener, ObservableCard {
	
	private IBoard board;
	private CardView cardInMotion;
	private PileView pileInMotion;
	private BoardView boardView;
	private boolean isCardSet;
	private PileView dragPile;
	private boolean isDragSet;
	private Point prePointOffset;
	private Point framePoint;
	
	public CardController(IBoard board) {
		this.board = board;
		cardInMotion = null;
	}
	
	public CardController() {
		cardInMotion = null;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
		// when mouse double clicked, card is auto-stacked if appropriate spot is available
		if(e.getClickCount() == 2){
			cardInMotion = (CardView) e.getComponent();
			pileInMotion = (PileView) e.getComponent().getParent();
			board.stackAuto(pileInMotion.getName(), cardInMotion.getIndex());
			reset();
		} else if (e.getClickCount() == 1) {
			
			if (e.getComponent() instanceof CardView) {
				CardView card = (CardView) e.getComponent();
				PileView pile = (PileView) card.getParent();
				
				// only the top card of the pile shows face up
				if (card.equals(pile.getTopCard())) {
					if (!card.getIsFaceUp()) {
						board.flip(card.getIndex(), ((PileView) card.getParent()).getName());
					}
				}
			}
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		prePointOffset = e.getPoint();
		e.getLocationOnScreen();
		framePoint = e.getComponent().getParent().getParent().getParent().getLocationOnScreen();
		
		if (boardView == null) {
			if (e.getComponent().getParent().getParent() instanceof BoardView) {
				this.boardView = (BoardView) e.getComponent().getParent().getParent();
			}
		}

		
		Component clickedComponent = SwingUtilities.getDeepestComponentAt(e.getComponent(), e.getX(), e.getY());

	    if (clickedComponent instanceof CardView) {
	        cardInMotion = (CardView) clickedComponent;
	        
	        if (!cardInMotion.getIsFaceUp()) {
	            reset();
	            return;
	        }
	        
	        pileInMotion = (PileView) cardInMotion.getParent();
	        isDragSet = true;
	        isCardSet = true;

	        System.out.println("Card is clicked");
	    } else if (clickedComponent instanceof FoundationView) {
	        System.out.println("Foundation is clicked");
	    } else if (clickedComponent instanceof TableauView) {
	        System.out.println("Tableau is clicked");
	    } else if (clickedComponent instanceof PileView) {
	        System.out.println("Pile is clicked");
	    }
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		
		if (!isCardSet) {
			return;
		}
		
		Component[] components = this.boardView.getComponents();
		boolean handled = false;
		
		for (Component c : components) {
			Rectangle tempBounds = c.getBounds();
			tempBounds.x += framePoint.x;
			tempBounds.y += framePoint.y;

		    if (tempBounds.contains(e.getXOnScreen(), e.getYOnScreen() - 42)) {
		        if (c instanceof PileView) {
		        	PileView pile = (PileView) c;
		        	if (!pile.getName().equals("drag") && !pile.getName().equals(pileInMotion.getName())) {
			        	try {
							board.stack(pile.getName(), pileInMotion.getName(), cardInMotion.getIndex());
							handled = true;
							break;
						} catch (Exception e1) {
							pileInMotion.mergePile(dragPile);
							handled = true;
							break;
						}

		        	}
		        }
		    }
		}
		if (!handled) {
			pileInMotion.mergePile(dragPile);
		}
		if (dragPile != null) {
	    	boardView.remove(dragPile);
	    	boardView.repaint();
		}
    	reset();
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		
	}
	
	@Override
	public void reset() {
		cardInMotion.highlightOff();
		cardInMotion = null;
		pileInMotion = null;
		isCardSet = false;
		dragPile = null;
		isDragSet = false;
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public CardView getCardInMotion() {
		return cardInMotion;
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		
		if (!isCardSet) {
			return;
		}
		
		Point currentPoint = e.getLocationOnScreen();

		if (isDragSet) {
			dragPile = new TableauView((currentPoint.x - framePoint.x) - prePointOffset.x, (currentPoint.y - framePoint.y) - prePointOffset.y);
			dragPile.setName("drag");
			dragPile.setCards(pileInMotion.getCardsSplitAtIndex(cardInMotion.getIndex()));
			boardView.add(dragPile, JLayeredPane.DRAG_LAYER);
			boardView.revalidate();
			boardView.repaint();
			isDragSet = false;
			return;
		}
		
		if (dragPile != null && boardView != null) {
			dragPile.setLocation((currentPoint.x - framePoint.x) - prePointOffset.x, (currentPoint.y - framePoint.y) - prePointOffset.y);
			boardView.repaint();
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {}
}
