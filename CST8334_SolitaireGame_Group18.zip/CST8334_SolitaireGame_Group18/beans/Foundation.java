package beans;

import java.util.ArrayList;


/**
 * The Class Foundation.
 */
public class Foundation extends Pile {
	
	private boolean isFull;

	public Foundation(String name) {
		super(name);
	}

	/**
	 * Validate.
	 *
	 * @param card the card
	 * @return true, if successful
	 */
	protected boolean validate(Card card) {
		
		if (pileList.size() == 13) {
			isFull = true;
		}
		
		// when the foundation is empty, only A(ce) is allowed
		if (this.isEmpty() && card.getValueAsInt() == 1) {
			return true;
		}

		// when foundation is not empty, only same suit and value of card + 1 is allowed
		if (card.getSuit() == peek(getTopCardIndex()).getSuit()
				&& card.getValueAsInt() == peek(getTopCardIndex()).getValueAsInt() + 1) {
			return true;
		}
		return false;
	}
	
	public boolean isFull() {
		return isFull;
	}
	
	@Override
	public void remove(int i) {
		super.remove(i);
		isFull = false;
	}

	@Override
	public void add(ArrayList<Card> cards) throws Exception{
		throw new Exception();
	}
}
