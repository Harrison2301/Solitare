package beans;

import java.util.ArrayList;

import constants.Names;

/**
 * The Class Talon.
 */
public class Talon extends Pile {

	/**
	 * Instantiates a new Talon.
	 */
	public Talon() {
		super(Names.TAL_NAME);
	}
	
	public Card findCard(String pileName, int index) throws Exception {
		if (pileName.contentEquals(Names.TAL_NAME)){
			return pileList.get(index);
		}
		throw new Exception();
	}
	
	/**
	 * Show. All cards in the Talon are always face up. Therefore, this method needs
	 * to be called whenever new cards are placed in the Talon to force visibility.
	 */
	@Override
	public void add(Card card) {
		card.show();
		this.pileList.add(card);
		updateViews();
	}

	@Override
	public void add(ArrayList<Card> cards) {
		for (Card c : cards) {
			c.show();
			this.pileList.add(c);
		}
		updateViews();
	}

	@Override
	protected boolean validate(Card card) {
		return true;
	}
}
