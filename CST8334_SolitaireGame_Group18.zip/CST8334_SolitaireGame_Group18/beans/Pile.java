package beans;

import java.util.ArrayList;

import view.ObservablePileView;


/**
 * The Class Pile.
 */
public abstract class Pile implements IPile {

	protected ArrayList<Card> pileList;
	protected String name;
	protected ObservablePileView view;
	protected boolean isViewSet;

	/**
	 * Instantiates a new pile.
	 */
	public Pile(String name) {
		this.pileList = new ArrayList<Card>();
		this.name = name;
	}

	/**
	 * Returns the pile's name
	 * 
	 * @return the pile's name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Size.
	 *
	 * @return the int
	 */
	public int size() {
		return this.pileList.size();
	};

	/**
	 * Adds a card to the top of a pile.
	 *
	 * @param card the card
	 */
	public void add(Card card) throws Exception {
		if (validate(card)) {
			this.pileList.add(card);
			updateViews();
		} else {

			throw new Exception();
		}
	}

	public void addNoValidate(Card card) {
		this.pileList.add(card);
		updateViews();
	}

	protected abstract boolean validate(Card card);

	/**
	 * Removes a card from at specific index (e.g. remove(3) removes the 4th card,
	 * counting from the bottom.)
	 *
	 * @param index the index
	 */
	public void remove(int index) {
		this.pileList.remove(index);
		updateViews();
	}

	/**
	 * Peek. Returns the card at a given index for pile.
	 *
	 * @param index the index
	 * @return the card
	 */
	public Card peek(int index) {
		return pileList.get(index);
	}

	/**
	 * Gets the pile.
	 *
	 * @return the pile
	 */
	public ArrayList<Card> getPile() {
		return this.pileList;
	}

	/**
	 * Checks if pile is empty.
	 *
	 * @return true, if is empty
	 */
	@Override
	public boolean isEmpty() {
		return pileList.isEmpty();
	};

	/**
	 * Gets the top card index.
	 *
	 * @return the top card index
	 */
	public int getTopCardIndex() {
		return pileList.size() - 1;
	}

	@Override
	public void setup(Card card) {
		this.pileList.add(card);
		updateViews();
	}

	@Override
	public void attachView(ObservablePileView view) {
		this.view = view;
		this.isViewSet = true;
	}

	@Override
	public abstract void add(ArrayList<Card> cards) throws Exception;

	@Override
	public void updateViews() {
		if (isViewSet) {
			view.update(pileList);
		} else {
			System.out.println("View not set");
		}
	}

	@Override
	public void clear() {
		pileList.clear();
		updateViews();
	}
}
