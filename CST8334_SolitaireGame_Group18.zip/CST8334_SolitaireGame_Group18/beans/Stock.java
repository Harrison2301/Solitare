package beans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import constants.Names;

/**
 * The Class Stock.
 */
public class Stock extends Pile {

	/**
	 * Instantiates a new stock.
	 */
	public Stock() {
		super(Names.STK_NAME);
		this.pileList = new ArrayList<Card>();

		for (Suit suit : Suit.values()) {
			for (int j = 1; j < 14; j++) {
				Card cardToAdd = new Card(j, suit);
				cardToAdd.hide();
				this.pileList.add(cardToAdd);
			}
		}
		this.shuffle();
	}
	
	/**
	 * Shuffle.
	 */
	public void shuffle() {
		Random randSeed = new Random();
		int size = this.size();

		// loop through each card in deck, and swap it with another random card in the
		// deck
		for (int i = 0; i < size; i++) {
			Collections.swap(pileList, i, randSeed.nextInt(size));
		}
	}

	/**
	 * Gets the top card index.
	 *
	 * @return the top card index
	 */
	public int getTopCardIndex() {
		return pileList.size() - 1;
	}

	@Override
	public void add(ArrayList<Card> cards) throws Exception {
		if (validate(cards.get(0))) {
			this.pileList = new ArrayList<Card> (cards);
			updateViews();
		} else {
			throw new Exception();
		}
	}

	@Override
	public boolean validate(Card card) {
		if (this.isEmpty()) {
			return true;
		}
		return false;
	}
}
