package beans;

import java.util.ArrayList;

/**
 * The Class Tableau.
 */
public class Tableau extends Pile {


	/**
	 * Instantiates a new tableau. Makes an ArrayList of Piles all facedown cards
	 * can be whatever order, all faceup cards must obey regular Solitaire rules
	 * (sequential but alternating colour).
	 */
	
//	public Tableau() {
//		this.tableauList = new Hashtable<String, Pile>();
//
//		// 7 stacks in the Tableau, instantiating a new Pile for each stack
//		for (int i = 0; i < 7; i++) {
//			tableauList.put(Names.getTableauName(i), new Pile());
//		}
//	}

//	/**
//	 * Sets the up tableau.
//	 *
//	 * @param stock the new up tableau
//	 */
//	public void setupTableau(Pile stock) {
//		// 7 stacks in Foundation
//		// Each stack is dealt a progressively larger number of cards.
//		// i.e.
//		// 1st stack, 1 card
//		// 2nd stack, 2 cards
//		// 3rd stack, 3 cards, etc
//		// Top most card of each stack in the Foundation is faceup, all other cards
//		// start facedown.
//		Card tempCard;
//		for (int i = 0; i < 7; i++) {
//			for (int j = 0; j < (i + 1); j++) {
//
//				// get top card of Stock
//				tempCard = stock.peek(stock.getTopCardIndex());
//
//				// remove it from Stock
//				stock.remove(stock.getTopCardIndex());
//
//				// add to the correct stack in Foundation
//				tableauList.get(Names.getTableauName(i)).add(tempCard);
//
//				// The top most card of each stack should be visible
//				// i.e. when i == j
//				// stack 0, card 0
//				// stack 1, card 1
//				// stack 4, card 4 (remember, index of 0 is bottom most card of stack)
//				if (i == j) {
//					tableauList.get(Names.getTableauName(i)).peek(j).show();
//				}
//			}
//		}
//	}
//
//	/**
//	 * Gets the tableau list.
//	 *
//	 * @return the tableau list
//	 */
//	public Hashtable<String, Pile> getTableauList() {
//		return this.tableauList;
//	}
//
//	/**
//	 * Find card.
//	 *
//	 * @param pileName  the pile name
//	 * @param cardIndex the card index
//	 * @return the card
//	 * @throws Exception the exception
//	 */
//	public Card findCard(String pileName, int cardIndex) throws Exception {
////		if (tableauList.containsKey(pileName)) {
////			return tableauList.get(pileName).getPile().get(cardIndex);
////		}
////		throw new Exception();
////	}
//
//	/**
//	 * Stack card.
//	 *
//	 * @param key  the key
//	 * @param card the card
//	 * @throws Exception the exception
//	 */
//	@Override
//	public void stackCard(String key, Card card) throws Exception {
//		if (validate(key, card)) {
//			this.tableauList.get(key).add(card);
//		} else {
//			throw new Exception();
//		}
//	}
//	
//	public void stackCard(String key, ArrayList<Card> cards) throws Exception{
//		if (validate(key , cards.get(0))) {
//			for (int i = 0; i < cards.size(); i++) {
//				this.tableauList.get(key).add(cards.get(i));
//			}
//		} else {
//			throw new Exception();
//		}
//	}
//
//	/**
//	 * Adds the card.
//	 *
//	 * @param key  the key
//	 * @param card the card
//	 */
//	public void addCard(String key, Card card) {
//		this.tableauList.get(key).add(card);
//	}

	public Tableau(String name) {
		super(name);
		}

	/**
	 * Validate.
	 *
	 * @param card the card
	 * @return true, if successful
	 */
	protected boolean validate(Card card) {

		// when tableau is empty only a K is allowed
		if (isEmpty() && card.getValueAsInt() == 13) {
			return true;
		}

		// only opposing colours may stack
		if (card.getIsRed() != peek(getTopCardIndex()).getIsRed()
				&& card.getValueAsInt() == peek(getTopCardIndex()).getValueAsInt() - 1) {
			return true;
		}
		return false;
	}

	@Override
	public void add(ArrayList<Card> cards) throws Exception {
		if (validate(cards.get(0))) {
			for (Card c : cards ) {
				this.pileList.add(c);
			}
			updateViews();
		} else {
			throw new Exception();
		}
	}
}
