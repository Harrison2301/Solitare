package beans;

import java.util.*;
import java.util.Map.Entry;
import constants.Names;
import view.BoardView;
import view.ObservableBoardView;
import view.PileView;

public class Board implements IBoard {

	private Hashtable<String, IPile> pileList;
	private int cardDraw = 1;
	private Hashtable<Boolean, List<String>> lastMove = new Hashtable<>();

	public Board() {
		init();
	}

	public void setupTableau() {
		Card tempCard;
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < (i + 1); j++) {
				int topCard = pileList.get(Names.STK_NAME).getTopCardIndex();

				tempCard = pileList.get(Names.STK_NAME).peek(topCard);
				pileList.get(Names.getTableauName(i)).setup(tempCard);
				pileList.get(Names.STK_NAME).remove(topCard);

				if (i == j) {
					pileList.get(Names.getTableauName(i)).peek(j).show();
				}
			}
		}

		for (int i = 0; i < 7; i++) {
			pileList.get(Names.getTableauName(i)).updateViews();
		}
	}

	public void init() {
		pileList = new Hashtable<String, IPile>();

		Stock stock = new Stock();
		Talon talon = new Talon();

		pileList.put(stock.getName(), stock);
		pileList.put(talon.getName(), talon);

		for (int i = 0; i < 4; i++) {
			Foundation foundation = new Foundation(Names.getFoundationName(i));
			pileList.put(foundation.getName(), foundation);
		}

		for (int i = 0; i < 7; i++) {
			Tableau tableau = new Tableau(Names.getTableauName(i));
			pileList.put(tableau.getName(), tableau);
		}

	}

	public void attachBoard(ObservableBoardView view) {
	}

	public void mapViews(Hashtable<String, PileView> views) {
		for (Entry<String, PileView> view : views.entrySet()) {
			pileList.get(view.getKey()).attachView(view.getValue());
		}
	}

	public IPile getStock() {
		return pileList.get(Names.STK_NAME);
	}

	public IPile getTalon() {
		return pileList.get(Names.TAL_NAME);
	}

	public IPile getFoundation(int i) {
		return pileList.get(Names.getFoundationName(i));
	}

	public IPile getTableau(int i) {
		return pileList.get(Names.getTableauName(i));
	}

	@Override
	public Hashtable<String, IPile> getPiles() {
		return pileList;
	}

	public void stack(String to, String from, int index) throws Exception {
		if (index == pileList.get(from).getTopCardIndex()) {
			try {
//				System.out.println("From: " + from + ", To: " + to);
				moveCard(to, from, index);
			} catch (Exception e) {
				throw new Exception();
			}
		} else {
			try {
				moveCards(to, from, index);
			} catch (Exception e) {
				throw new Exception();
			}
		}
	}

	public void stackAuto(String from, int index) {
		if (index == pileList.get(from).getTopCardIndex()) {
			for (int j = 0; j < Names.FD_NAMES.length; j++) {
				try {
					moveCard(Names.FD_NAMES[j], from, index);
				} catch (Exception e) {
				}
			}

			for (int i = 0; i < Names.TB_NAMES.length; i++) {
				try {
					moveCard(Names.TB_NAMES[i], from, index);
				} catch (Exception e) {
				}
			}
		} else {
			for (int i = 0; i < Names.TB_NAMES.length; i++) {
				try {
					moveCards(Names.TB_NAMES[i], from, index);
				} catch (Exception e) {
				}
			}
		}
	}

	public void undo() {
		if (lastMove.containsKey(true)) {
			try {
				// return card from where it was, with no checks
				String from = lastMove.get(true).get(0);
				String to = lastMove.get(true).get(1);
				Integer index = Integer.parseInt(lastMove.get(true).get(2));

				Card card = pileList.get(to).peek(index);
				pileList.get(from).addNoValidate(card);
				pileList.get(to).remove(index);

				lastMove.clear();

				if (BoardView.gameMode == "regular") {
					addToScore(-25);
				}

				else if (BoardView.gameMode == "vegas") {
					addToScore(-5);
				}

			} catch (Exception e) {
			}
		}
		// return multiple cards back
		else if (lastMove.containsKey(false)) {
			try {
				String from = lastMove.get(false).get(0);
				String to = lastMove.get(false).get(1);
				Integer index = Integer.parseInt(lastMove.get(false).get(2));

				int topIndex = pileList.get(to).getTopCardIndex();
				for (int i = index + 1; i <= topIndex; i++) {
					Card card = pileList.get(to).peek(i);
					pileList.get(from).addNoValidate(card);
				}
				for (int j = topIndex; j > index; j--) {
					pileList.get(to).remove(j);
				}

				lastMove.clear();

				if (BoardView.gameMode == "regular") {
					addToScore(-25);
				}

				else if (BoardView.gameMode == "vegas") {
					addToScore(-5);
				}

			} catch (Exception e) {
			}
		}
	}

	private void moveCard(String to, String from, int index) throws Exception {
		if (to.contains(Names.TAL_NAME)) {
			if (!from.contains(Names.STK_NAME)) {
				throw new Exception();
			}
		}

		Card card = pileList.get(from).peek(index);
		pileList.get(to).add(card);
		pileList.get(from).remove(index);

		if (BoardView.gameMode == "regular") {

			if ((from.contains(Names.TB_NAME) || (from.contains(Names.TAL_NAME))) && to.contains(Names.FD_NAME)) {
				addToScore(20);
				System.out.println("Card moved to foundation!");
			}

			else if (from.contains(Names.FD_NAME) && to.contains(Names.TB_NAME)) {
				addToScore(-30);
				System.out.println("Card moved down to tableau.");
			}

			else if (from.contains(Names.TAL_NAME) && to.contains(Names.TB_NAME)) {
				addToScore(10);
				System.out.println("Card moved to tableau!");
			}

		}

		else if (BoardView.gameMode == "vegas") {

			if ((from.contains(Names.TB_NAME) || (from.contains(Names.TAL_NAME))) && to.contains(Names.FD_NAME)) {
				addToScore(5);
				System.out.println("Card moved to foundation!");
			}

			else if (from.contains(Names.FD_NAME) && to.contains(Names.TB_NAME)) {
				addToScore(-5);
				System.out.println("Card moved down to tableau.");
			}

		}

		lastMove.clear();
		List<String> fromTo = Arrays.asList(from, to, String.valueOf(pileList.get(to).getTopCardIndex()));
		lastMove.put(true, fromTo);
	}

	private void moveCards(String to, String from, int index) throws Exception {
		int topIndex = pileList.get(from).getTopCardIndex();
		int toIndex = pileList.get(to).getTopCardIndex();
		for (int i = index; i <= topIndex; i++) {
			moveCard(to, from, index);
		}

		lastMove.clear();
		List<String> fromTo = Arrays.asList(from, to, String.valueOf(toIndex));
		lastMove.put(false, fromTo);
	}

	private void refreshStock() {
		ArrayList<Card> cards = new ArrayList<>(pileList.get(Names.TAL_NAME).getPile());
		Collections.reverse(cards);
		try {
			pileList.get(Names.STK_NAME).add(cards);
		} catch (Exception e) {
			return;
		}
		pileList.get(Names.TAL_NAME).clear();
		pileList.get(Names.TAL_NAME).updateViews();
		pileList.get(Names.TAL_NAME).updateViews();

	}

	@Override
	public void refreshTalon() {
		if (pileList.get(Names.STK_NAME).isEmpty()) {
			refreshStock();
			return;
		}

		for (int i = 0; i < cardDraw; i++) {
			try {
				moveCard(Names.TAL_NAME, Names.STK_NAME, pileList.get(Names.STK_NAME).getTopCardIndex());
				pileList.get(Names.TAL_NAME).updateViews();
				pileList.get(Names.STK_NAME).updateViews();
			} catch (Exception e) {
				return;
			}
		}
	}

	@Override
	public void flip(int index, String pile) {
		pileList.get(pile).peek(index).show();
		pileList.get(pile).updateViews();
		if (BoardView.gameMode == "regular") {
			addToScore(15);
		}
		lastMove.clear();
	}



	protected static void addToScore(int points) {
		BoardView.score += points;
		String newScore = "  Score: " + BoardView.score;
		BoardView.scoreBox.setText(newScore);
		BoardView.scoreBox.repaint();
	}
}
