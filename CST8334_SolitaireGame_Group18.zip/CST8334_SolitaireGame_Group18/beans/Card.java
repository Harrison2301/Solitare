package beans;

/**
 * The Class Card.
 */
public class Card {

	/**
	 * The value and suit of card is final, cannot be changed after instantiated.
	 */
	private final Integer value;
	private final Suit suit;
	private final boolean isRed;
	private boolean isFaceUp;

	/**
	 * Instantiates a new card. Must pass in value and suit, colour determined by
	 * suit.
	 *
	 * @param value the value
	 * @param suit  the suit
	 */
	//
	public Card(int value, Suit suit) {
		this.value = value;
		this.suit = suit;

		if (suit == Suit.Clubs || suit == Suit.Spades) {
			this.isRed = false;
		} else {
			this.isRed = true;
		}
	}

	/**
	 * Gets the value as string.
	 *
	 * @return the value as string
	 */
	public String getValueAsString() {
		switch (this.value) {
		case 11:
			return "J";
		case 12:
			return "Q";
		case 13:
			return "K";
		case 1:
			return "A";
		default:
			return this.value.toString();
		}
	}

	/**
	 * Gets the value as int.
	 *
	 * @return the value as int
	 */
	public int getValueAsInt() {
		return this.value;
	}

	/**
	 * Gets the suit.
	 *
	 * @return the suit
	 */
	public Suit getSuit() {
		return this.suit;
	}

	/**
	 * Gets the face up state of card.
	 *
	 * @return true if card is face up.
	 */
	public boolean getIsFaceUp() {
		return this.isFaceUp;
	}

	/**
	 * Gets the colour state of card.
	 *
	 * @return true if card is red.
	 */
	public boolean getIsRed() {
		return this.isRed;
	}

	/**
	 * Show. Turn card face up.
	 */
	public void show() {
		this.isFaceUp = true;
	}

	/**
	 * Hide. Turn card face down.
	 */
	public void hide() {
		this.isFaceUp = false;
	}
}
