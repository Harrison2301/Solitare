package beans;

import java.util.ArrayList;

import view.ObservablePileView;

public interface IPile {
	String getName();
	void add(Card card) throws Exception;
	void add(ArrayList<Card> cards) throws Exception;
	void addNoValidate(Card card);
	void remove(int index);
	Card peek(int index);
	ArrayList<Card> getPile();
	int getTopCardIndex();
	void attachView(ObservablePileView view);
	void setup(Card card);
	void clear();
	boolean isEmpty();
	void updateViews();
}
