package beans;

import java.util.Hashtable;

import view.PileView;

public interface IBoard {
	void stack(String to, String from, int index) throws Exception;
	void stackAuto(String from, int index);
	void undo();
	Hashtable<String, IPile> getPiles();
	void refreshTalon();
	void setupTableau();
	void mapViews(Hashtable<String, PileView> views);
	void flip(int index, String pile);
}
