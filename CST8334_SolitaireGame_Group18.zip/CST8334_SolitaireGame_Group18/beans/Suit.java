package beans;

/**
 * The Enum Suit. Possible playing card suits.
 */
public enum Suit {

	Hearts, Clubs, Diamonds, Spades

}
