package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.border.Border;
import constants.ViewConstants;

/**
 * The Class TalonView.
 */
public class TalonView extends PileView {

	private static final long serialVersionUID = -134207793496679175L;

	/**
	 * Instantiates a new talon view.
	 *
	 * @param x the x co-ordinate
	 * @param y the y co-ordinate
	 */
	public TalonView(int x, int y) {
		super(x, y);
		super.setSize(ViewConstants.CARD_WIDTH, ViewConstants.CARD_HEIGHT);
		this.setLayout(new GridLayout(0,1));
	}
	
	public void clear() {
		if (cards.isEmpty()) {
			return;
		}
		
		remove(cards.get(this.getTopCardIndex()));
		super.cards.clear();
		this.repaint();
	}

	/**
	 * Paint component.
	 *
	 * @param graph the graphic component
	 */
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setColor(Color.orange);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		Border border = BorderFactory.createLineBorder(Color.black, 1);
		this.setBorder(border);
		
		if (isEmpty()) {
		} else {
			removeAll();
			add(cards.get(this.getTopCardIndex()));
			setVisible(true);
		}
	}

}
