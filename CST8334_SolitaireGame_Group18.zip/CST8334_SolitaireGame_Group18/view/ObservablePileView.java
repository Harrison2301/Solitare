package view;

import java.util.ArrayList;

import beans.Card;

public interface ObservablePileView {
	void update(ArrayList<Card> cards);
}
