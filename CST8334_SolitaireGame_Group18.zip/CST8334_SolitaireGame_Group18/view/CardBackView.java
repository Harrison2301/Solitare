package view;

import java.awt.Image;
import javax.swing.ImageIcon;
import constants.ViewConstants;

/**
 * The Class CardBackView.
 */
public class CardBackView {

	/**
	 * Gets the back of card.
	 *
	 * @return the back of card
	 */
	public static Image getBackOfCard() {
		ImageIcon imgI = new ImageIcon(CardView.class.getResource(ViewConstants.DIR + "/" + ViewConstants.CARD_BACK + ViewConstants.EXT));
		Image image = imgI.getImage();
		return image;
	}
}
