package view;

import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import javax.swing.ImageIcon;
import constants.ViewConstants;


/**
 * The Class FoundationView.
 */
public class FoundationView extends PileView {

	private static final long serialVersionUID = -4392308908462456214L;
	private int suit;

	/**
	 * Instantiates a new foundation view.
	 *
	 * @param x the x co-ordinate
	 * @param y the y co-ordinate
	 * @param i the suit number
	 */
	public FoundationView(int x, int y, int i) {
		super(x, y);
		super.setSize(ViewConstants.CARD_WIDTH, ViewConstants.CARD_HEIGHT);
		this.suit = i;
		this.setLayout(new GridLayout(0,1));
	}
	
	/**
	 * Gets the card suit image.
	 *
	 * @param suit the suit
	 * @return the base suit image
	 */
	public static final Image getFdBase(int suit) {
		ImageIcon imgI = new ImageIcon(CardView.class.getResource(ViewConstants.DIR + "/" + ViewConstants.FD_BASE + suit + ViewConstants.EXT));
		Image image = imgI.getImage();
		return image;
	}

	/**
	 * Paint component.
	 *
	 * @param g the graphics component
	 */
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(getFdBase(suit), 0, 0, this.getWidth(), this.getHeight(), this);
		if (this.isEmpty()) {
		} else {
			if (this.getTopCardIndex() != 0) {
			remove(cards.get(this.getTopCardIndex()-1));
			}
			add(cards.get(this.getTopCardIndex()));
		}
	}

}
