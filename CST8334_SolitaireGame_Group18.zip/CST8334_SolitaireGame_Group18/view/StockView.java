package view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;

import beans.Card;
import constants.ViewConstants;

/**
 * The Class StockView.
 */
public class StockView extends PileView {

	private static final long serialVersionUID = 3177105431047996566L;

	/**
	 * Instantiates a new stock view.
	 *
	 * @param x the x co-ordinate
	 * @param y the y co-ordinate
	 */
	public StockView(int x, int y) {
		super(x, y);
		super.setSize(ViewConstants.CARD_WIDTH, ViewConstants.CARD_HEIGHT);
	}
	
	public void update(ArrayList<Card> c) {
		cards.clear();
		this.removeAll();
		
		for (int i = 0; i < c.size(); i++) {
			Card card = c.get(i);
			CardView cardView = new CardView(card, i);
			cards.add(cardView);
		}
		
		this.resetComponents();
	}

	/**
	 * Paint component.
	 *
	 * @param graph the graphics object
	 */
	@Override
	protected void paintComponent(Graphics graph) {
		super.paintComponent(graph);
		Graphics2D graph2d = (Graphics2D) graph;

		graph2d.setStroke(new BasicStroke(5));
		graph2d.setColor(Color.white);
		graph2d.drawRect(0, 0, 72, this.getHeight());

		graph.drawImage(CardBackView.getBackOfCard(), 0, 0, 72, this.getHeight(), this);

	}

}
