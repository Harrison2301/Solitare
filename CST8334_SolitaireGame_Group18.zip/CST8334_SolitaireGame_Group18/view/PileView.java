package view;

import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import javax.swing.JPanel;

import beans.Card;

/**
 * The Class PileView.
 */
public abstract class PileView extends JPanel implements ObservablePileView {

	private static final long serialVersionUID = -8869623120625154244L;
	protected int x, y;
	protected ArrayList<CardView> cards;
	protected String viewName;
	protected boolean isHighlighted;
	protected MouseListener cardController;
	protected ArrayList<CardView> splitCards;

	/**
	 * Instantiates a new pile view.
	 *
	 * @param x the x co-ordinate
	 * @param y the y co-ordinate
	 */
	public PileView(int x, int y) {
		super.setLocation(x, y);
		cards = new ArrayList<>();
		splitCards = new ArrayList<>();
	}
	
	public void setCards(ArrayList<CardView> cards) {
		this.cards = new ArrayList<>(cards);
	}
	
	public ArrayList<CardView> getCardsSplitAtIndex(int index) {
		
		if (!splitCards.isEmpty()) {
			splitCards.clear();
		}
		
		int size = cards.size();
		for (int i = index; i < size; i++) {
			splitCards.add(cards.get(index));
			cards.remove(index);
		}
		return splitCards;
	}
	
	public void mergePile(PileView pile) {
		cards.addAll(splitCards);
		splitCards.clear();
		this.resetComponents();
	}
	
	public void setCardController(MouseListener cardController) {
		this.cardController = cardController;
	}

	/**
	 * Sets the name of the view.
	 *
	 * @param name the new view name
	 */
	public void setName(String name) {
		this.viewName = name;
	}

	/**
	 * Gets the name of the view.
	 *
	 * @return the view name
	 */
	public String getName() {
		return viewName;
	}

	/**
	 * Checks if is empty.
	 *
	 * @return true, if is empty
	 */
	public boolean isEmpty() {
		return this.cards.isEmpty();
	}

	/**
	 * Gets the top card index.
	 *
	 * @return the top card index
	 */
	public int getTopCardIndex() {
		return cards.size() - 1;
	}
	
	
	public ArrayList<CardView> getCardViews(){
		return cards;
	}

	
	public void setHighlighted(boolean isHighlighted) {
		this.isHighlighted = isHighlighted;
	}
	
	public void update(ArrayList<Card> c) {
		cards.clear();
		this.removeAll();
		
		if (c.isEmpty()) {
			this.addMouseListener(BoardView.getPileControllerInstance());
			this.resetComponents();
			return;
		}
		
		for (int i = 0; i < c.size(); i++) {
			Card card = c.get(i);
			CardView cardView = new CardView(card, i);
			cardView.addMouseListener(BoardView.getCardControllerInstance());
			cardView.addMouseMotionListener((MouseMotionListener) BoardView.getCardControllerInstance());
			cards.add(cardView);
		}
		
		this.resetComponents();
	}
	
	public void resetComponents() {
		revalidate();
		repaint();
	}
	
	public void highlightOn(int index) {
		for (int i = index; i <= getTopCardIndex(); i++) {
			cards.get(i).highlightOn();
		}
		resetComponents();
	}
	
	public void highlightOff(int index) {
		for (int i = index; i <= getTopCardIndex(); i++) {
			cards.get(i).highlightOff();
		}
		resetComponents();
	}
	
	
	
	/**
	 * Gets the top card of the pile.
	 *
	 * @return the top card
	 */
	public CardView getTopCard() {
        if (!cards.isEmpty()) {
            return cards.get(cards.size() - 1);
        } else {
            return null;
        }
    }
	
}
