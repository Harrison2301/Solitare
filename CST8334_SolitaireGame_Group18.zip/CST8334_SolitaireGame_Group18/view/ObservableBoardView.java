package view;

public interface ObservableBoardView {
	void win();
}
