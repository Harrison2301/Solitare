package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseListener;
import java.util.Hashtable;
import javax.swing.JLayeredPane;
import javax.swing.JTextField;
import constants.Names;
import constants.ViewConstants;

/**
 * The Class BoardView.
 */
public class BoardView extends JLayeredPane {

	private static final long serialVersionUID = 393232085409051446L;
	Hashtable<String, PileView> pileViewList;
	protected static int Xs = 80;
	static MouseListener cardController;
	static MouseListener pileController;
	
	public static JTextField scoreBox = new JTextField();
	public static int score;
	public static String gameMode;

	/**
	 * Instantiates a new board view.
	 */
	public BoardView(MouseListener cardController, MouseListener pileController, String gameMode) {
		super.setLayout(null);
		BoardView.gameMode = gameMode;
		BoardView.cardController = cardController;
		BoardView.pileController = pileController;
		pileViewList = new Hashtable<String, PileView>();
		initializePile();
		initControllers();
		initializeScore();
	}
	
	public static MouseListener getCardControllerInstance() {
		return cardController;
	}
	
	public static MouseListener getPileControllerInstance() {
		return pileController;
	}

	/**
	 * Initialize pile.
	 */
	private void initializePile() {
		// create StockView and attach to panel
		StockView stock = new StockView(ViewConstants.DECK_POSITION.x, ViewConstants.DECK_POSITION.y);
		stock.setName(Names.STK_NAME);
		stock.setCardController(cardController);
		add(stock, JLayeredPane.DEFAULT_LAYER);
		pileViewList.put(stock.getName(), stock);

		// create talon and attach to panel
		TalonView talon = new TalonView(ViewConstants.DECK_POSITION.x - Xs, ViewConstants.DECK_POSITION.y);
		talon.setName(Names.TAL_NAME);
		talon.setCardController(cardController);
		add(talon, JLayeredPane.DEFAULT_LAYER);
		pileViewList.put(talon.getName(), talon);

		// create 4 foundations and attach to panel
		for (int i = 0; i < 4; ++i) {
			// create new view and set name
			FoundationView view = new FoundationView(20 + Xs * i, 20, i + 1);
			view.setName(Names.getFoundationName(i));
			view.setCardController(cardController);
			pileViewList.put(view.getName(), view);
			add(view, JLayeredPane.DEFAULT_LAYER);
		}

		// create 7 tableaus and attach to panel
		for (int i = 0; i < 7; i++) {
			// create new tableau and set name
			TableauView view = new TableauView(ViewConstants.TABLE_POSITION.x + ViewConstants.TABLE_OFFSET * (i), ViewConstants.TABLE_POSITION.y);
			view.setName(Names.getTableauName(i));
			view.setCardController(cardController);
			pileViewList.put(view.getName(), view);
			add(view, JLayeredPane.DEFAULT_LAYER);
		}
	}
	
	public void initControllers() {
		pileViewList.get(Names.STK_NAME).addMouseListener(pileController);
		
		for (String name : Names.getFdNames()) {
			pileViewList.get(name).addMouseListener(pileController);
		}
	}
	
	public Hashtable<String, PileView> getPileViewList() {
		return pileViewList;
	}


	@Override
	protected void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);
		graphics.setColor(Color.CYAN);
		graphics.fillRect(0, 0, this.getWidth(), this.getHeight());
	}
	

	private void initializeScore() {
		scoreBox.setBounds(20, 450, 120, 30);
		if (gameMode == "regular") {
			score = 0;
			scoreBox.setText("  Score: 0");
		}
		else if (gameMode == "vegas") {
			score = -52;
			scoreBox.setText("  Score: -52");
		}
		scoreBox.setEditable(false);
		scoreBox.setOpaque(false);
		add(scoreBox, JLayeredPane.DEFAULT_LAYER);
	}
}
