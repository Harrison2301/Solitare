package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.border.Border;

import beans.Card;
import beans.Suit;
import constants.ViewConstants;

/**
 * The Class CardView.
 */
public class CardView extends JLabel {

	private static final long serialVersionUID = 1L;
	private Image img;
	private boolean isFaceUp;
	private int index;
	private boolean isHighlighted;


	public CardView(Card card, int index) {
		this.isFaceUp = card.getIsFaceUp();
		this.index = index;

		try {
			ImageIcon icon = new ImageIcon(
					getClass().getResource(ViewConstants.DIR + cardFile(card.getSuit(), card.getValueAsInt())));
			img = icon.getImage();
		}

		catch (Exception e) {
			System.err.println(e.getMessage());
		}

		this.setMinimumSize(new Dimension(ViewConstants.CARD_WIDTH, ViewConstants.CARD_HEIGHT));
		this.setPreferredSize(new Dimension(ViewConstants.CARD_WIDTH, ViewConstants.CARD_HEIGHT));
		this.setMaximumSize(new Dimension(ViewConstants.CARD_WIDTH, ViewConstants.CARD_HEIGHT));
	}

	public int getIndex() {
		return index;
	}

	/**
	 * Gets the checks if is face up.
	 *
	 * @return the checks if is face up
	 */
	public boolean getIsFaceUp() {
		return isFaceUp;
	}

	/**
	 * Card file.
	 *
	 * @param suit  the suit
	 * @param value the value
	 * @return the string
	 */
	private String cardFile(Suit suit, int value) {
		char character = 0;

		if (suit == Suit.Hearts) {
			character = 'h';
		} else if (suit == Suit.Spades) {
			character = 's';
		} else if (suit == Suit.Diamonds) {
			character = 'd';
		} else if (suit == Suit.Clubs) {
			character = 'c';
		}

		if (value < 10) {
			return "/0" + value + character + ViewConstants.EXT;
		}

		else {
			return "/" + value + character + ViewConstants.EXT;
		}
	}

	/**
	 * Gets the card image.
	 *
	 * @return the card image
	 */
	public Image getCardImage() {
		if (!isFaceUp) {
			return CardBackView.getBackOfCard();
		}
		return img;
	}

	/**
	 * Show. Turns card face up.
	 */
	public void show() {
		isFaceUp = true;
	}

	public void highlightOn() {
		isHighlighted = true;
		Border border = BorderFactory.createLineBorder(Color.black, 5);
		this.setBorder(border);
	}

	public void highlightOff() {
		isHighlighted = false;
		this.setBorder(null);
	}

	public boolean isHighlighted() {
		return isHighlighted;
	}

	/**
	 * Paint component.
	 *
	 * @param g the graphics component
	 */
	@Override
	protected void paintComponent(Graphics g) {
		g.drawImage(getCardImage(), 0, 0, this.getWidth(), this.getHeight(), this);
		super.paintComponent(g);
	}
}
