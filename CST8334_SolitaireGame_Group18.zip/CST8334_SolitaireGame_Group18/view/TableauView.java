package view;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.OverlayLayout;
import constants.ViewConstants;

/**
 * The Class TableauView.
 */
public class TableauView extends PileView {

	private static final long serialVersionUID = -4678995071142434859L;


	/**
	 * Instantiates a new tableau view.
	 *
	 * @param x    the x co-ordinate
	 * @param y    the y co-ordinate
	 * @param size the size
	 */
	public TableauView(int x, int y) { 
		super(x, y);
		super.setSize(ViewConstants.CARD_WIDTH, ViewConstants.TB_HEIGHT);
		super.setOpaque(false);
		super.setLayout(new OverlayLayout(this));
	}

	/**
	 * Paint component.
	 *
	 * @param g the graphic component
	 */
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Graphics2D graph2d = (Graphics2D) g;
		graph2d.setColor(Color.white);
		graph2d.drawLine(0, 0, this.getWidth(), 0);
		graph2d.drawLine(0, 0, 0, 96);
		graph2d.drawLine(this.getWidth() - 1, 0, this.getWidth() - 1, 96);
		graph2d.drawLine(this.getWidth(), 0, 0, 96);
		graph2d.drawLine(0, 0, this.getWidth() + 1, 96);

		graph2d.setPaint(new GradientPaint(36, 0, new Color(255, 255, 255, 160), 36, 60, new Color(0, 0, 0, 0)));
		graph2d.fillRect(0, 0, this.getWidth(), this.getHeight());
		
		if (!this.isEmpty()) { 

			int topIndex = super.getTopCardIndex();
			
			for (int i = topIndex; i >= 0; i --) {
				CardView card = cards.get(i);
				card.setLocation(0, (i * 20));
				this.add(card);
			}

			this.revalidate();
		}
	}

}
