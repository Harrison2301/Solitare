package game;

import java.awt.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import javax.swing.*;
import beans.Board;
import beans.IBoard;
import constants.ViewConstants;
import controller.CardController;
import controller.PileController;
import view.BoardView;

/**
 * This is the entry point of the Solitaire Game application.
 * 
 * @author 2023F CST8334_450 Group 18
 * @version assignment3
 *
 */
public class SolitaireGame extends JFrame {

	private static final long serialVersionUID = -4144492843221485718L;

	static protected BoardView gameBoardView;
	static protected CardController cardController;
	static protected PileController pileController;
	static protected IBoard gameBoard;
	static protected String gameMode;

	/**
	 * Starts the application.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		gameMode = "regular";
		SolitaireGame game = new SolitaireGame();
		game.setVisible(true);
	}


	public SolitaireGame() {
		JMenuBar menuBar = new JMenuBar();
		JMenu menuFile = new JMenu("Game mode");
		menuBar.add(menuFile);
		
		
		// New regular game
		JMenuItem menuItemNewRegularGame = new JMenuItem("New Regular Game");
		menuItemNewRegularGame.addActionListener(event -> {
			dispose();
			gameMode = "regular";
			new SolitaireGame().setVisible(true);
			BoardView.score = 0;
		});
		menuFile.add(menuItemNewRegularGame);

		
		// New Vegas game
		JMenuItem menuItemNewVegasGame = new JMenuItem("New Vegas Game");
		menuItemNewVegasGame.addActionListener(event -> {
			dispose();
			gameMode = "vegas";
			new SolitaireGame().setVisible(true);
			BoardView.score = -52;
		});
		menuFile.add(menuItemNewVegasGame);


		
		// Rules for the game
		JMenuItem menuHelp = new JMenuItem("Rules");
		menuBar.add(menuHelp);
		menuHelp.addActionListener(clickEvent -> {
		        try {
					Desktop.getDesktop().browse(new URI("https://bicyclecards.com/how-to-play/solitaire/"));
				} catch (IOException | URISyntaxException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		});
		this.setJMenuBar(menuBar);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gameBoard = new Board();
		cardController = new CardController(gameBoard);
		pileController = new PileController(gameBoard);
		pileController.attachObserver(cardController);
		gameBoardView = new BoardView(cardController, pileController, gameMode);
		gameBoardView.setPreferredSize(new Dimension(ViewConstants.BOARD_WIDTH, ViewConstants.BOARD_HEIGHT));
		add(gameBoardView);
		gameBoard.mapViews(gameBoardView.getPileViewList());
		gameBoard.setupTableau();
		pack();
	}

}
