package constants;

import java.awt.Point;

public class ViewConstants {
	public static final String EMPTY = "empty", FD_BASE = "fdBase0", CARD_BACK = "back";
	public static final String DIR = "cards", EXT = ".png";
	public static final int CARD_WIDTH = 72, CARD_HEIGHT = 92, TB_HEIGHT = 450;
	public static final Point DECK_POSITION = new Point(500, 20);
	public static final int BOARD_WIDTH = 640, BOARD_HEIGHT = 500;
	public static final Point TABLE_POSITION = new Point(20, 150);
	public static final int TABLE_OFFSET = 80;
}
