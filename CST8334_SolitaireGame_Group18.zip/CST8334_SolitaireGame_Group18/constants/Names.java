package constants;

import java.util.Arrays;
import java.util.List;

public class Names {
	public static final String FD_NAME = "FND";
	public static final String TB_NAME = "TB";
	public static final String[] FD_NAMES = {"FND1", "FND2", "FND3", "FND4"};
	public static final String[] TB_NAMES = {"TB1", "TB2", "TB3", "TB4", "TB5", "TB6", "TB7"};
	public static final String STK_NAME = "STK";
	public static final String TAL_NAME = "TAL";
	
	public static String getFoundationName(int i) {
		return FD_NAMES[i];
	}
	
	public static String getTableauName(int i) {
		return TB_NAMES[i];
	}
	
	public static List<String> getFdNames(){
		return (List<String>) Arrays.asList(FD_NAMES);
	}
	
	public static List<String> getTbNames(){
		return (List<String>) Arrays.asList(TB_NAMES);
	}
	
}
